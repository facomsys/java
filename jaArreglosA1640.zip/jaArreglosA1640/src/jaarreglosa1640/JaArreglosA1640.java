/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jaarreglosa1640;

/**
 *
 * @author usr0
 */
public class JaArreglosA1640 {

/**
 * @param args the command line arguments
 */
public static void main(String[] args) {
    // TODO code application logic here
    float [] sueldos = new float [12];
    String [] materias = new String [6];
    System.out.println("sueldos:\n"+listarSueldos(sueldos));
    System.out.println("materias:\n"+listarMaterias(materias));
    System.out.println("sueldos:"+tamaño(sueldos));
    System.out.println("materias:"+tamaño(materias));
    System.out.println("materias:"+tamaño(materias));
    
    System.out.println("sueldos:\n"+listarSueldos(sueldos));
    sueldosSet (sueldos, 0, 500F);
    sueldosSet (sueldos, 1, 800F);
    sueldosSet (sueldos, 2, 1200F);
    System.out.println("sueldos:\n"+listarSueldos(sueldos));
    
    System.out.println("materias:\n"+listarMaterias(materias));
    materiasSet (materias, 0, "Java");
    materiasSet (materias, 1, "Php");
    materiasSet (materias, 2, "Python");
    System.out.println("materias:\n"+listarMaterias(materias));
}

//Actualizar valores para el arreglo materias
public static void materiasSet (String [] arreglo, int indice, String valor){
    arreglo[indice]=valor;
}

//Actualizar valores para el arreglo sueldos
public static void sueldosSet (float [] arreglo, int indice, float valor){
    arreglo[indice]=valor;
}

//Obtener el tamaño de un arreglo de tipo primitivo
public static int tamaño (float [] arreglo){
    return arreglo.length;
}

//Obtener el tamaño de un arreglo de tipo Object
public static int tamaño (Object [] arreglo){
    return arreglo.length;
}

//Obtener el tamaño de un arreglo de tipo String
public static int tamañoMaterias (String [] arreglo){
    return arreglo.length;
}

//Obtener la lista de elementos de un arreglo String con foreach
public static String listarMaterias (String [] arreglo){
    String resultado="";
    for (String elemento:arreglo)
        resultado+=elemento+"\n";
    return resultado;
}

//Obtener la lista de elementos de un arreglo float con for
public static String listarSueldos (float [] arreglo){
    String resultado="";
    for (int i=0; i<arreglo.length;i++)
        resultado+=arreglo[i]+"\n";
    return resultado;
}
}