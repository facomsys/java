/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jaarreglosa1642;

/**
 *
 * @author usr0
 */
public class JaArreglosA1642 {

/**
 * @param args the command line arguments
 */
public static void main(String[] args) {
    // TODO code application logic here
    int [] ventas = {24, 15, 25, 19, 16};
    System.out.println("ventas:" + tamaño (ventas));
    System.out.println("primer venta:"+venta0(ventas));
    System.out.println("venta 1:"+ventaN(ventas,1));
    System.out.println("venta 2:"+ventaN(ventas,2));
    System.out.println("venta 4:"+ventaN(ventas,4));
    System.out.println("ventas:\n"+lista(ventas));
    System.out.println("ventas:\n"+listaV2(ventas));
    arregloSet (ventas, 0, 30);
    arregloSet (ventas, 2, 70);
    arregloSetV2 (ventas, 4, 50);
    System.out.println("ventas:\n"+listaV2(ventas));
    System.out.println("suma:"+arregloSuma (ventas));
    System.out.println("promedio:"+arregloPromedio (ventas));
    System.out.println("mayor:"+mayor (ventas));
    System.out.println("menor:"+menor (ventas));
}

public static int menor (int [] arreglo){
    int resultado=arreglo[0];
    for (int elemento: arreglo)
        resultado=Math.min(resultado, elemento);
    return resultado;
}

public static int mayor (int [] arreglo){
    int resultado=arreglo[0];
    for (int elemento: arreglo)
        resultado=Math.max(resultado, elemento);
    return resultado;
}

public static float arregloPromedio (int [] arreglo){
    return arregloSuma(arreglo)/ (float) arreglo.length;
}

public static int arregloSuma (int [] arreglo){
   int suma=0;
   for (int elemento: arreglo)
      suma+=elemento;
   return suma;
}

public static void arregloSetV2 (int [] arreglo, int posicion, int valor){
   if (posicion>=0 && posicion<arreglo.length){
      arreglo[posicion]=valor;
   }
}

public static void arregloSet (int [] arreglo, int posicion, int valor){
   arreglo[posicion]=valor;
}

public static String listaV2 (int [] arreglo){
   String resultado="";
   for (int elemento: arreglo)
      resultado+=elemento + "\n";
   return resultado;
}

public static String lista (int [] arreglo){
   String resultado="";
   for (int i=0; i<arreglo.length; i++)
      resultado+=arreglo[i] + "\n";
   return resultado;
}

public static int ventaN (int [] arreglo, int posicion){
   return arreglo[posicion];
}

public static int venta0 (int [] arreglo){
   return arreglo[0];
}

public static int tamaño (int [] arreglo){
   int resultado=0;
   resultado=arreglo.length;
   return resultado;
}
}