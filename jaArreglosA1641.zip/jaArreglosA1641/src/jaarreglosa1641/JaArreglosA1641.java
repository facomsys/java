/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jaarreglosa1641;

/**
 *
 * @author usr0
 */
public class JaArreglosA1641 {

/**
 * @param args the command line arguments
 */
public static void main(String[] args) {
    // TODO code application logic here
int [] unidadesVendidas = {24, 15, 25, 19, 16};
String [] compañias = {"Telcel","Nextel","IUSACELL","Unefon"};
    System.out.println("unidades vendidas:\n"+unidadesVendidasListar(unidadesVendidas));
    System.out.println("compañias:\n"+compañiasListar(compañias));
}

//Listado de elementos de un arreglo de tipo int
public static String unidadesVendidasListar (int [] arreglo){
    String resultado="";
    for(int elemento:arreglo)
        resultado+=elemento+"\n";
    return resultado;
}

//Listado de elementos de un arreglo de tipo String
public static String compañiasListar (String [] arreglo){
    String resultado="";
    for(String elemento:arreglo)
        resultado+=elemento+"\n";
    return resultado;
}
}